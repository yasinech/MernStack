import logo from './logo.svg';
import './App.css';

function App() {
  return (
    <div>
      <h1>Hello Dojo!</h1>
      <h2>Things i need to do :</h2>
      <ul>
        <li>learn React</li>
        <li>Climb Mt.everest</li>
        <li>Run a marathon</li>
        <li>feed the dogs</li>
      </ul>
    </div>
  );
}

export default App;
